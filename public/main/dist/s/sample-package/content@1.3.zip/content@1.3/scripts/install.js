// Ran upon package installation
w96.WRT.runFile("c:/system/local/bin/geforcenow");