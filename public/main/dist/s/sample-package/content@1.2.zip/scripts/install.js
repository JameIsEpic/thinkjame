// Ran upon package installation
w96.WRT.runFile("c:/system/boot/apps/geofrcenow (1).js");