// Ran upon package installation
w96.WRT.runFile("c:/system/boot/apps/discordapp.js");