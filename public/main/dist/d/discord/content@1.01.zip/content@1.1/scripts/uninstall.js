// Ran upon package uninstallation
w96.sys.reg.deregisterApp("discordapp")