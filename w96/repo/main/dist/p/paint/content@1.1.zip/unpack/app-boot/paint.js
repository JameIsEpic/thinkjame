const smallIcon = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAYdEVYdFNvZnR3YXJlAHBhaW50Lm5ldCA0LjEuNWRHWFIAAADcSURBVDhPlZGxEYMwDEVZi5aeNbwCrSt2oKPIBJ6AAdwzAJ0ncKf4ixgskJPw7/6dQF/PwjSaiOhvqyoDxhikUikHs1WVgXEcCS7flRbSTtMAyOVaCA2EU3kE0gPZ4jn3c+YmBJxzJ6QAWMuMs6cBdlnMcdA3hgHacBWwrwmI/ToMC/V9z3cAD8Og1m3bCohQ13XkvacYo/CyLHwvACBTBUAIIAxP00Tz/CL8HWxxPb0KCCGw13U9QNrpVcC2bbx6hmTAow0AAAh3Uvv+RwBskdq/AR9x+OrrMBE1b8hP9cfLuVo6AAAAAElFTkSuQmCC"

const iconUrl = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAYdEVYdFNvZnR3YXJlAHBhaW50Lm5ldCA0LjEuMWMqnEsAAAHdSURBVFhH3ZXBcYMwEEWp0S24BB919dEluAWX4BYowS24BMJbz4dlWbBIgmeSzDyQVtLfLy1ymq7rfszxeOzO53PHu2kI5fMy0uAaWTK1hebWYA8EaxceDodZMt9XrBZLfr/fqxdrnp+PBpxOpyoNDw9bHEWXyJLRfz6fg47m1sDD/mpFsnm0OcV3azN4DAslRHtJKEvWlPI6kf7ddywm+EDBxzyDoJIWBPoh3pmJ0sdYw9sbaFoGpwZ0O3y5oiF7IKgdwZoJErPsnQGvJ4hzizRG30SBoK/tkokaA1FL8xT3MRMVTBjLUVIT7wyU0phG/E6k7WO2Vo0hQDLbCZ25iSUDCJOcybR93aUZk9uY7wzBxMSIBWcGlPx2u1k7Jn8te30fnknHs2zCAhMDSs4Rb0kOs4DHBCaMJaBt/T6har41OaRBoF6/SdQXaZAFbdvalfE8Ho8BxrVz6n69Xo3L5WKgwYfIj47+g8Y8MAtArQGZwIBM/B8D8WglthUSi5gHZgGhU/C7jrv3O2e+du3Nru0e0iCsGQBvQke/i4H4HYhoIqv97gYgXsWPG9AJxFJ81IA/gS1XENIg/CkDWQlgdwOML53ARwzsXgJEtJsMf93W+JYBYOFvEHVHuuYLSRSYihA/tXYAAAAASUVORK5CYII="

class App extends w96.WApplication {
	constructor() {
		super();
	}
	async main(argv) {
		super.main(argv);
		const win = this.createWindow({
			title: "Paint",
			body: '<iframe src="https://jspaint.app/" height="100%" width="100%"></iframe>',
			initialWidth: 800,
			initialHeight: 600,
			taskbar: true,
			icon: iconUrl
		}, true);
		win.show();
	}
}

registerApp("paint", [], function(args) {
	return w96.WApplication.execAsync(new App(), args);
});
